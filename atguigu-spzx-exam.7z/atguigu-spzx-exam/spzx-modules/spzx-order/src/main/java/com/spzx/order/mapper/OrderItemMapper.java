package com.spzx.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.spzx.domain.OrderItem;

public interface OrderItemMapper extends BaseMapper<OrderItem> {

}
