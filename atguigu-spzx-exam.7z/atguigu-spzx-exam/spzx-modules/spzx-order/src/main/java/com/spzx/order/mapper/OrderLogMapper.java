package com.spzx.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.spzx.domain.OrderLog;

public interface OrderLogMapper extends BaseMapper<OrderLog> {

}