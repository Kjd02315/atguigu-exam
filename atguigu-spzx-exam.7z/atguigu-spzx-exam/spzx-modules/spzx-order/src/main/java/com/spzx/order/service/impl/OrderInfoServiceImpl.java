package com.spzx.order.service.impl;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageInfo;
import com.spzx.domain.OrderInfo;
import com.spzx.domain.OrderItem;
import com.spzx.order.mapper.OrderInfoMapper;
import com.spzx.order.mapper.OrderItemMapper;
import com.spzx.order.mapper.OrderLogMapper;
import com.spzx.order.service.IOrderInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 订单Service业务层处理
 */
@Service
public class OrderInfoServiceImpl extends ServiceImpl<OrderInfoMapper, OrderInfo> implements IOrderInfoService {
    @Autowired
    private OrderInfoMapper orderInfoMapper;

    @Autowired
    private OrderItemMapper orderItemMapper;

    @Autowired
    OrderLogMapper orderLogMapper;

    @Override
    public PageInfo<OrderInfo> selectUserOrderInfoList(Integer pageNum, Integer pageSize, Integer orderStatus) {


        // 获取当前登录用户的id
        Long userId = 1L;
        LambdaQueryWrapper<OrderInfo> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(OrderInfo::getUserId, userId)
                .eq(orderStatus != null, OrderInfo::getOrderStatus, orderStatus);
        List<OrderInfo> orderInfos = orderInfoMapper.selectList(queryWrapper);
        for (OrderInfo orderInfo : orderInfos) {
            // 根据订单id查询订单项
            LambdaQueryWrapper<OrderItem> orderItemQueryWrapper = new LambdaQueryWrapper<>();
            orderItemQueryWrapper.eq(OrderItem::getOrderId, orderInfo.getId());
            orderInfo.setOrderItemList(orderItemMapper.selectList(orderItemQueryWrapper));
        }

        return new PageInfo<>(orderInfos);
    }

    @Override
    public OrderInfo getByOrderNo(String orderNo) {
        LambdaQueryWrapper<OrderInfo> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(OrderInfo::getOrderNo, orderNo);
        OrderInfo orderInfo = orderInfoMapper.selectOne(queryWrapper);
        // 根据订单id查询订单项
        LambdaQueryWrapper<OrderItem> orderItemQueryWrapper = new LambdaQueryWrapper<>();
        orderItemQueryWrapper.eq(OrderItem::getOrderId, orderInfo.getId());
        orderInfo.setOrderItemList(orderItemMapper.selectList(orderItemQueryWrapper));

        return orderInfo;
    }
}

