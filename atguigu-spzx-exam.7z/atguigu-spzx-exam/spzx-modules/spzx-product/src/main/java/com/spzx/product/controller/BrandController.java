package com.spzx.product.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.PageInfo;
import com.spzx.domain.Brand;
import com.spzx.product.service.IBrandService;
import com.spzx.vo.Result;
import com.spzx.vo.ResultCodeEnum;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


@Tag(name = "品牌管理")
@RestController
@RequestMapping("/brand")
public class BrandController {

    @Autowired
    private IBrandService brandService;

    @Operation(summary = "新增品牌")
    @PostMapping
    public Result addBrand(@RequestBody @Validated Brand brand) {
        boolean save = brandService.save(brand);
        return Result.build(save, save ? ResultCodeEnum.SUCCESS : ResultCodeEnum.FAIL);
    }

    @Operation(summary = "修改品牌")
    @PutMapping
    public Result editBrand(@RequestBody @Validated Brand brand) {
        return Result.build(brandService.updateById(brand), ResultCodeEnum.SUCCESS);
    }

    @Operation(summary = "获取品牌详细信息")
    @GetMapping(value = "{id}")
    public Result getBrandDetails(@PathVariable("id") Long brandId) {
        return Result.build(brandService.getById(brandId), ResultCodeEnum.SUCCESS);
    }

    @Operation(summary = "分页查询品牌列表")
    @GetMapping("/findPage/{page}/{limit}")
    public Result<Page<Brand>> findBrandList(@PathVariable Integer page, @PathVariable Integer limit) {
        Page<Brand> brandPage = brandService.findByPage(page, limit);
        return Result.build(brandPage, ResultCodeEnum.SUCCESS);
    }

    @Operation(summary = "删除品牌")
    @DeleteMapping("/{ids}")
    public Result removeBrand(@PathVariable Long ids) {
        return Result.build(brandService.removeById(ids), ResultCodeEnum.SUCCESS);
    }
}
