package com.spzx.product.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.spzx.domain.Brand;
import com.spzx.vo.Result;

/**
 * 品牌Mapper接口
 */
public interface BrandMapper extends BaseMapper<Brand> {


}
