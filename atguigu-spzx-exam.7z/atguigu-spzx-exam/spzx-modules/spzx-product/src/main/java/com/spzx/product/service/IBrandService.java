package com.spzx.product.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.github.pagehelper.PageInfo;
import com.spzx.domain.Brand;

/**
 * 品牌Service接口
 */
public interface IBrandService extends IService<Brand> {


    Page<Brand> findByPage(Integer page, Integer limit);
}
