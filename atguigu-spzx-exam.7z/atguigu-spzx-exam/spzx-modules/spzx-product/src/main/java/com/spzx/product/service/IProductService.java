package com.spzx.product.service;

import com.spzx.vo.SkuLockVo;

import java.util.List;

public interface IProductService {

}
